# In-class coding 8: socket
# Author: Jun Cai
How to run:
	- To start the servers: './satrt N' where N is an integer larger than 1
	- To check if a number is a prime: './check M' where M is a positive integer
